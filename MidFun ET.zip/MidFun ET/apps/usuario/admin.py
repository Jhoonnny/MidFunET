from django.contrib import admin
from apps.usuario.models import registro,metas
# Register your models here.
admin.site.register(registro)
admin.site.register(metas)